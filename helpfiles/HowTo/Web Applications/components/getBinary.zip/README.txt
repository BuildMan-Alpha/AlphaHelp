To add the getBinary.js node service to your Alpha Anywhere workspace:

1. Open or create a workspace
2. Open the Web Projects Control Panel
3. Select "Node Services" in the left-hand column
4. Click "Add File"
5. Navigate to the location where getBinary.js was extracted and select the file.
6. Click OK.