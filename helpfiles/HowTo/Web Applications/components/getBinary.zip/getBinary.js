exports.handler = function(packet,response,sendResponse) {
    var fs = require('fs');
    var fn = packet.filename;

    function _cb(error,data) {
        if (error) {
            response.error = error;
            sendResponse(response,null);
        } else {
            var attachments = [{name: packet.filename, data: data}];
            response.result = true;
            sendResponse(response,attachments);
        }
    };
    
    fs.readFile(fn,_cb);
};

