﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
//using System.ServiceModel.Web;
using System.Text;
using System.IO;
using System.ServiceModel.Description;


namespace ExampleWCFService
	{
	public static class Util
		{
		// Extension methods
		internal static String Indent(this System.String Value, Int32 Level = 0)
			{
			if (Level < 1)
				return Value;
			System.Text.StringBuilder Builder = new System.Text.StringBuilder(Level);
			for (Int32 i = 0; i < Level; i++)
				{
				Builder.Append("\t");
				}
			return Builder.ToString() + Value;
			}

		internal static String FormatNestedExceptions(this System.Exception Ex, Int32 Indent = 0)
			{
			String Result = Ex.Message;
			if (Ex.InnerException != null)
				Result += "\r\n" + Ex.InnerException.FormatNestedExceptions(Indent + 1);
			return Result.Indent(Indent);
			}

		private static Dictionary<String, Product>	m_Products = null;
		private static Dictionary<String, Customer> m_Customers = null;

		internal static Dictionary<String, Product> Products	
			{
			get {
				if (m_Products == null)
					{
					m_Products = new Dictionary<String, Product>()
						{

						{ "Cola 12oz 24 Count",
						new Product()
							{
							Name			= "Cola 12oz 24 Count",
							UnitOfMeasure	= UnitOfMeasure.Units,
							Price			= 1.49M 
							}
						},
						{ "Orange Soda 12oz 24 Count",
						new Product()
							{
							Name			= "Orange Soda 12oz 24 Count",
							UnitOfMeasure	= UnitOfMeasure.Units,
							Price			= 2.10M, 
							}
						},
						{ "Ginger Ale 12oz 24 Count",
						new Product()
							{
							Name			= "Ginger Ale 12oz 24 Count",
							UnitOfMeasure	= UnitOfMeasure.Units,
							Price			= 1.05M, 
							}
						},
						{ "Club Soda 12oz 24 Count",
						new Product()
							{
							Name			= "Club Soda 12oz 24 Count",
							UnitOfMeasure	= UnitOfMeasure.Units,
							Price			= 0.80M, 
							}
						},
						{ "Root Beer 12oz 24 Count",
						new Product()
							{
							Name			= "Root Beer 12oz 24 Count",
							UnitOfMeasure	= UnitOfMeasure.Units,
							Price			= 1.80M, 
							}
						},
						{ "Cola 32oz Bottle",
						new Product()
							{
							Name			= "Cola 32oz Bottle",
							UnitOfMeasure	= UnitOfMeasure.Units,
							Price			= 0.29M, 
							}
						},
						{ "Orange Soda 32oz Bottle",
						new Product()
							{
							Name			= "Orange Soda 32oz Bottle",
							UnitOfMeasure	= UnitOfMeasure.Units,
							Price			= 0.39M, 
							}
						},
						{ "Ginger Ale 32oz Bottle",
						new Product()
							{
							Name			= "Ginger Ale 32oz Bottle",
							UnitOfMeasure	= UnitOfMeasure.Units,
							Price			= 0.27M, 
							}
						},
						{ "Club Soda 32oz Bottle",
						new Product()
							{
							Name			= "Club Soda 32oz Bottle",
							UnitOfMeasure	= UnitOfMeasure.Units,
							Price			= 0.10M, 
							}
						},
						{ "Root Beer 32oz Bottle",
						new Product()
							{
							Name			= "Root Beer 32oz Bottle",
							UnitOfMeasure	= UnitOfMeasure.Units,
							Price			= 0.36M, 
							}
						},
						{ "Cola",
						new Product()
							{
							Name			= "Cola",
							UnitOfMeasure	= UnitOfMeasure.Ounces,
							Price			= 0.03M, 
							}
						},
						{ "Orange Soda",
						new Product()
							{
							Name			= "Orange Soda",
							UnitOfMeasure	= UnitOfMeasure.Ounces,
							Price			= 0.06M, 
							}
						},
						{ "Ginger Ale",
						new Product()
							{
							Name			= "Ginger Ale",
							UnitOfMeasure	= UnitOfMeasure.Ounces,
							Price			= 0.03M, 
							}
						},
						{ "Club Soda",
						new Product()
							{
							Name			= "Club Soda",
							UnitOfMeasure	= UnitOfMeasure.Ounces,
							Price			= 0.02M, 
							}
						},
						{ "Root Beer",
						new Product()
							{
							Name			= "Root Beer",
							UnitOfMeasure	= UnitOfMeasure.Units,
							Price			= 0.07M, 
							}
						}
						};
					}
				return m_Products;
				}
			}
		internal static Dictionary<String, Customer> Customers	
			{
			get {
					m_Customers = new Dictionary<String, Customer>()
						{
						{ "American Soft Drink Company",  	
							new Customer() {
							CompanyName		= "American Soft Drink Company",
							StreetAddress	= "10003 Patriot Road",
							City			= "Boston",
							State			= "MA",
							Order = new List<Order>()
								{
								new Order()
									{ 
									CreateDate = new DateTime(2018, 1, 15), OpenDate = new DateTime(2018,1,15), ShipDate = new DateTime(2018,1,18),
										Item = new List<OrderItem>()
											{
											new OrderItem { Product = Products["Cola"], Quantity = 3000},
											new OrderItem { Product = Products["Orange Soda"], Quantity = 3000},
											new OrderItem { Product = Products["Root Beer 32oz Bottle"], Quantity = 20}
											}
									},
								new Order()
									{ 
									CreateDate = new DateTime(2018, 2, 16), OpenDate = new DateTime(2018,2,16), ShipDate = new DateTime(2018,2,17),
										Item = new List<OrderItem>()
											{
											new OrderItem { Product = Products["Cola"], Quantity = 4000},
											new OrderItem { Product = Products["Orange Soda"], Quantity = 4000},
											new OrderItem { Product = Products["Root Beer 32oz Bottle"], Quantity = 40}
											}
									},
								new Order()
									{ 
									CreateDate = new DateTime(2018, 3, 16), OpenDate = new DateTime(2018,3,16), ShipDate = new DateTime(2018,3,21),
										Item = new List<OrderItem>()
											{
											new OrderItem { Product = Products["Cola"], Quantity = 1000},
											new OrderItem { Product = Products["Orange Soda"], Quantity = 1000},
											new OrderItem { Product = Products["Root Beer 32oz Bottle"], Quantity = 30}
											}
									}
								}
							}
						},
						{ "South Shore Suppliers",  	
						new Customer()
							{
							CompanyName		= "South Shore Suppliers",
							StreetAddress	= "222 North Avenue West",
							City			= "Weymouth",
							State			= "MA",
							Order = new List<Order>()
								{
								new Order()
									{ 
									CreateDate = new DateTime(2018, 1, 11), OpenDate = new DateTime(2018,1,11), ShipDate = new DateTime(2018,1,12),
										Item = new List<OrderItem>()
											{
											new OrderItem { Product = Products["Cola"], Quantity = 7500},
											new OrderItem { Product = Products["Ginger Ale"], Quantity = 8500},
											new OrderItem { Product = Products["Root Beer"], Quantity = 9000},
											new OrderItem { Product = Products["Root Beer 32oz Bottle"], Quantity = 500}
											}
									},
								new Order()
									{ 
									CreateDate = new DateTime(2018, 2, 12), OpenDate = new DateTime(2018,2,12), ShipDate = new DateTime(2018,2,12),
										Item = new List<OrderItem>()
											{
											new OrderItem { Product = Products["Cola"], Quantity = 7500},
											new OrderItem { Product = Products["Ginger Ale"], Quantity = 8500},
											new OrderItem { Product = Products["Root Beer"], Quantity = 9000},
											new OrderItem { Product = Products["Root Beer 32oz Bottle"], Quantity = 500}
											}
									},
								new Order()
									{ 
									CreateDate = new DateTime(2018, 3, 16), OpenDate = new DateTime(2018,3,16), ShipDate = new DateTime(2018,3,21),
										Item = new List<OrderItem>()
											{
											new OrderItem { Product = Products["Cola"], Quantity = 7500},
											new OrderItem { Product = Products["Ginger Ale"], Quantity = 8500},
											new OrderItem { Product = Products["Root Beer"], Quantity = 9000},
											new OrderItem { Product = Products["Root Beer 32oz Bottle"], Quantity = 500}
											}
									}
								}
							}
						},
						{"MidMass Beverages", 
						new Customer()
							{
							CompanyName		= "MidMass Beverages",
							StreetAddress	= "12 Central Street",
							City			= "Worcester",
							State			= "MA",
							Order = new List<Order>()
								{
								new Order()
									{ 
									CreateDate = new DateTime(2018, 1, 11), OpenDate = new DateTime(2018,1,11), ShipDate = new DateTime(2018,1,12),
										Item = new List<OrderItem>()
											{
											new OrderItem { Product = Products["Cola 12oz 24 Count"], Quantity = 17500},
											new OrderItem { Product = Products["Ginger Ale 12oz 24 Count"], Quantity = 18500},
											new OrderItem { Product = Products["Root Beer 12oz 24 Count"], Quantity = 19000},
											new OrderItem { Product = Products["Club Soda 12oz 24 Count"], Quantity = 1500}
											}
									},
								new Order()
									{ 
									CreateDate = new DateTime(2018, 2, 12), OpenDate = new DateTime(2018,2,12), ShipDate = new DateTime(2018,2,12),
										Item = new List<OrderItem>()
											{
											new OrderItem { Product = Products["Cola 12oz 24 Count"], Quantity = 17500},
											new OrderItem { Product = Products["Ginger Ale 12oz 24 Count"], Quantity = 18500},
											new OrderItem { Product = Products["Root Beer 12oz 24 Count"], Quantity = 19000},
											new OrderItem { Product = Products["Club Soda 12oz 24 Count"], Quantity = 1500}
											}
									},
								new Order()
									{ 
									CreateDate = new DateTime(2018, 3, 16), OpenDate = new DateTime(2018,3,16), ShipDate = new DateTime(2018,3,21),
										Item = new List<OrderItem>()
											{
											new OrderItem { Product = Products["Cola 12oz 24 Count"], Quantity = 17500},
											new OrderItem { Product = Products["Ginger Ale 12oz 24 Count"], Quantity = 18500},
											new OrderItem { Product = Products["Root Beer 12oz 24 Count"], Quantity = 19000},
											new OrderItem { Product = Products["Club Soda 12oz 24 Count"], Quantity = 1500}
											}
									}
								}
							}	
						}
					};
				return m_Customers;
				}
			}

		internal static Customer GetCustomer(String Name)
			{
			if (!Customers.ContainsKey(Name))
				throw new KeyNotFoundException();
			return Customers[Name];
			}
		internal static List<String> ListCustomers()
			{
			List<String> Result = Customers.Keys.ToList();
			Result.Sort();
			return Result;
			}
		internal static List<String> ListProducts()
			{
			List<String> Result = Products.Keys.ToList();
			Result.Sort();
			return Result;
			}
		}
	}
