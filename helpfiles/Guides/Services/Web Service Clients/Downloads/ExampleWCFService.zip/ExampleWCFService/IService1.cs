﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace ExampleWCFService
	{
	[ServiceContract]
	public interface ICustomerService
		{

		[OperationContract]
		List<String> ListCustomers();

		[OperationContract]
		List<String> ListProducts();

		[OperationContract]
		Customer GetCustomer(String Name);
		}

	[DataContract]
	public class Customer
		{
		[DataMember]
		public bool IsActive;

		[DataMember]
		public String CompanyName;

		[DataMember]
		public String StreetAddress;

		[DataMember]
		public String City;

		[DataMember]
		public String State;

		[DataMember]
		public List<Order> Order;

		public Customer()
			{
			Order = new List<Order>();
			}
		}

	[DataContract]
	public class Order
		{
		[DataMember]
		public DateTime CreateDate;

		[DataMember]
		public DateTime OpenDate;

		[DataMember]
		public DateTime ShipDate;

		[DataMember]
		public List<OrderItem> Item;

		public Order()
			{
			Item = new List<OrderItem>();
			}
		}

	[DataContract]
	public class OrderItem
		{
		[DataMember]
		public Product Product;

		[DataMember]
		public Int32 Quantity;
		}

	[DataContract]
	public class Product
		{
		[DataMember]
		public String Name;

		[DataMember]
		public UnitOfMeasure UnitOfMeasure;

		[DataMember]
		public Decimal Price;
		}
	[DataContract]
	public enum UnitOfMeasure
		{
		[EnumMember]
		Units		= 1,
		[EnumMember]
		Ounces		= 2
		}
	}
