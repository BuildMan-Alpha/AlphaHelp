﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
//using System.ServiceModel.Web;
using System.Text;
using System.IO;
using System.ServiceModel.Description;


namespace ExampleWCFService
	{
	public class CustomerService : ICustomerService
		{
		public List<String> ListCustomers()
			{
			return Util.ListCustomers();
			}

		public List<String> ListProducts()
			{
			return Util.ListProducts();
			}

		public Customer GetCustomer(String Name)
			{
			return Util.GetCustomer(Name);
			}
		}

	class Program
		{
        static void Main(string[] args)
			{
			try {
	            // Create the ServiceHost.
				using (ServiceHost host = new ServiceHost(typeof(CustomerService)))
					{
					host.Open();
					Console.WriteLine("Application GUID: {0}", System.Reflection.Assembly.GetExecutingAssembly().GetType().GUID.ToString());
					Console.WriteLine("The service is ready at {0}", host.BaseAddresses[0]);
					Console.WriteLine("Press <Enter> to stop the service.");
					Console.ReadLine();
					// Close the ServiceHost.
					host.Close();
					}
				}
			catch (Exception Ex)
				{
				Console.WriteLine(Ex.Message);
				Console.WriteLine(Ex.FormatNestedExceptions());
				Console.ReadLine();
				}
            } // Main
        } // Class

	}
